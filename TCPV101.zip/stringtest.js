var dateformat = require('dateformat');
var date="11/20/1996";
console.log(dateformat(date,"ddd mmm dd yyyy"))